package org.wj.controllor;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.wj.entity.Priv;
import org.wj.entity.Role;
import org.wj.service.impl.RoleServiceImpl;

/**
 * Servlet implementation class UpdateRoleMsg
 */
@WebServlet("/role/UpdateRoleMsg.do")
@MultipartConfig
public class UpdateRoleMsg extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
        String rid = request.getParameter("rid");
        String rname = request.getParameter("rname");
        String[] pids = request.getParameterValues("pids");
        List<Priv> lp = new ArrayList<>();
        for (String pid : pids) {
            lp.add(new Priv(Integer.parseInt(pid)));
        }
        boolean b = new RoleServiceImpl().updateRoleByRid(new Role(Integer.parseInt(rid), rname, lp));
        if(b){
            request.setAttribute("msg","修改成功！");
        }else {
            request.setAttribute("msg","修改失败！");
        }
        String path=request.getServletContext().getContextPath();
        response.sendRedirect(path+"/admin/roleAction.do");
        //request.getRequestDispatcher("").forward(request,response);
    }
		
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
