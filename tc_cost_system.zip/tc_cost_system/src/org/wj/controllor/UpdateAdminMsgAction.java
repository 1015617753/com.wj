package org.wj.controllor;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.wj.entity.Admin;
import org.wj.service.impl.AdminServiceImpl;

/**
 * Servlet implementation class UpdateAdminMsgAction
 */
@WebServlet("/admin/UpdateAdminMsgAction.do")
public class UpdateAdminMsgAction extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateAdminMsgAction() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String id = request.getParameter("aid");
		String aname = request.getParameter("aname");
		String atel = request.getParameter("atel");
		String aemail = request.getParameter("aemail");
		
		//修改session的值
		Admin ad = (Admin) request.getSession().getAttribute("admin");
		ad.setAname(aname);
		ad.setAtel(atel);
		ad.setAemail(aemail);
		request.getSession().setAttribute("admin", ad);
		
		boolean b = new AdminServiceImpl().updateAdminMsg(new Admin(Integer.parseInt(id),aname,atel,aemail));
		if(b)
			response.getWriter().print("ok");
		else
			response.getWriter().print("fail");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
