package org.wj.controllor;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.wj.entity.Admin;
import org.wj.service.impl.AdminService;
import org.wj.service.impl.AdminServiceImpl;

/**
 * Servlet implementation class UpdateAction
 */
@WebServlet("/user/UpdateAction.do")
public class UpdateAction extends HttpServlet {
	private static final long serialVersionUID = 1L;
   

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String oldpwd = request.getParameter("oldpassword");
		String newpwd = request.getParameter("newpassword");
		String id = request.getParameter("id");
		
		Admin admin = (Admin) request.getSession().getAttribute("admin");
		if(oldpwd.equals(admin.getApwd())) {
			admin.setApwd(newpwd);
			AdminService admins = new AdminServiceImpl();
			boolean i = admins.updatePassword(new Admin(Integer.parseInt(id),newpwd));
			if(i) {
				/*request.getSession().setAttribute("Admin",admin);*/
				response.sendRedirect("../view/login.jsp");
			}
			else {
				request.setAttribute("msg","对不起，密码修改失败");
				response.sendRedirect("../view/user/user_modi_pwd.jsp");
			}
		}
		else {
				request.setAttribute("msg", "输入密码错误");
				response.sendRedirect("../view/user/user_modi_pwd.jsp");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
