package org.wj.controllor;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.wj.entity.Priv;
import org.wj.entity.Role;
import org.wj.service.impl.RoleServiceImpl;

/**
 * Servlet implementation class RoleAddAction
 */
@WebServlet("/role/RoleAddAction.do")
@MultipartConfig
public class RoleAddAction extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		String rname = request.getParameter("rname");
		String [] Myprivs = request.getParameterValues("myPrivs");
		List<Priv> lp = new ArrayList<>();
		for(String mypriv : Myprivs) {
			Priv pv = new Priv();
			pv.setPid(Integer.parseInt(mypriv));
			lp.add(pv);
		}
		
		Role rl = new Role();
		rl.setRname(rname);
		rl.setLp(lp);
		System.out.println(rl);
		boolean b = new RoleServiceImpl().addRole(rl);
		if(b) {
			request.setAttribute("msg", "添加成功");
			response.sendRedirect("../view/role/role_list.jsp");
			
		}else {
			request.setAttribute("msg", "添加失败");
			response.sendRedirect("../view/role/role_add.jsp");
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
