package org.wj.service.impl;

import java.util.List;

import org.wj.entity.Priv;
import org.wj.entity.Role;

public interface RoleService {
	/**
	 * 得到所有的角色，并将角色和角色所拥有的权限一一绑定
	 * @return
	 */
	public List<Role> showRole();
	public List<Role> getRoleById(int rid);
	public List<Priv> getAllPrivs();
	public boolean addRole(Role role);
	public boolean delRole(int rid);
	public boolean updateRole(Role role);
	
}
