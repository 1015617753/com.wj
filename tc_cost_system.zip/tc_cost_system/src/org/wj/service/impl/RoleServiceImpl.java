package org.wj.service.impl;

import java.util.List;

import org.wj.dao.PrivDao;
import org.wj.dao.RoleDao;
import org.wj.dao.impl.PrivDaoImpl;
import org.wj.dao.impl.RoleDaoImpl;
import org.wj.entity.Priv;
import org.wj.entity.Role;
import org.wj.service.impl.RoleService;

public class RoleServiceImpl implements RoleService {

	RoleDao roleDao = new RoleDaoImpl();
	PrivDao privDao = new PrivDaoImpl();
	public List<Role> showRole() {
		List<Role> lr = roleDao.selAllRole();
		for (Role role : lr) {
			List<Priv> lp = privDao.selPrivByRid(role.getId());
			role.setLp(lp);
		}
		
		return lr;
	}

	@Override
	public List<Role> getRoleById(int rid) {
		List<Role> role = roleDao.selRoleById(rid);
		List<Priv> lp = privDao.selPrivByRid(rid);
		((Role) role).setLp(lp);
		return role;
	}
	

	
	public List<Priv> getAllPrivs() {
		// TODO 自动生成的方法存根
		return privDao.selAllPrivs();
	}

	@Override
	public boolean addRole(Role role) {
		// TODO 自动生成的方法存根
		int i = roleDao.addRole(role);
		if(i != -1) {
			role.setId(i);
			roleDao.addRolePrivs(role);
			
		}
	
		return i!=-1?true:false;
		
	}

	@Override
	public boolean delRole(int rid) {
		// TODO 自动生成的方法存根
		int r = roleDao.deleteRlPriv(rid);
		int p = roleDao.deleteRoles(rid);
		return r+p>=2?true:false;
		
	}

	@Override
	public boolean updateRole(Role role) {
		// TODO 自动生成的方法存根
		int r = roleDao.updateRl(role);
		int p = roleDao.deleteRlPriv(role.getId());
		int rp = roleDao.addRolePrivs(role);
		return r+p+rp>=3?true:false;
	}

	public Role showRoleByRid(int rid) {
		// TODO 自动生成的方法存根
		Role role = roleDao.selRoleByRid(rid);
		List<Priv> lp = privDao.selPrivByRid(rid);
		role.setLp(lp);
		return role;
	}

	public boolean updateRoleByRid(Role role) {
		int i = roleDao.updateRoleByRid(role);
		int j = roleDao.delRoPrByRid(role.getId());
		int k = 0;
		for (Priv priv : role.getLp()) {
			k = roleDao.insertRoPr(role.getId(), priv.getPid());
		}
		return i > 0 && j > 0 && k > 0 ? true : false;
	}

}

