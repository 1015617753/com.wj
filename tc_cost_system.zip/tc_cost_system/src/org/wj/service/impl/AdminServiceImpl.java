package org.wj.service.impl;



import java.util.List;

import org.wj.dao.PrivDao;
import org.wj.dao.RoleDao;
import org.wj.dao.impl.AdminDao;
import org.wj.dao.impl.AdminDaoImpl;
import org.wj.dao.impl.PrivDaoImpl;
import org.wj.dao.impl.RoleDaoImpl;
import org.wj.entity.Admin;
import org.wj.entity.Priv;
import org.wj.entity.Role;

public class AdminServiceImpl implements AdminService {
	
	AdminDao adminDao = new AdminDaoImpl();
	PrivDao privDao = new PrivDaoImpl();
	RoleDao roleDao = new RoleDaoImpl();
	@Override
	public Admin checkLogin(Admin admin) {

		//根据用户名和密码查询数据库，查到了将结果封装到admin2中
		Admin admin2 = adminDao.selAdminByNP(admin);
		if(admin2 != null) {
			List<Priv> lp = privDao.selPrivByAid(admin2.getId());	//****使用admin2
			List<Role> lr = (List<Role>) roleDao.selRoleById(admin2.getId());
			
			admin2.setLp(lp);
			admin2.setLr(lr);
			
		}
		return admin2;
	}

	@Override
	public boolean updatePassword(Admin admin) {
		// TODO 自动生成的方法存根
		int i = adminDao.updatePassword(admin);
		if(i>0) return true;
		return false;
	}

	@Override
	public boolean updateAdminMsg(Admin admin) {
		// TODO 自动生成的方法存根
		int i = adminDao.updeteAdminMsg(admin);
		if(i>0) return true;
		return false;
	}
}
