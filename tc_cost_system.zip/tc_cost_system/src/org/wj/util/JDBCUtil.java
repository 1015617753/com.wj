package org.wj.util;



import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import javax.sql.DataSource;

import com.alibaba.druid.pool.DruidDataSourceFactory;

public class JDBCUtil {
	
	private static DataSource  ds = null;
	static Connection conn;
	static {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	static {
		FileInputStream in = null;
		
		try {
			
			Properties p = new Properties();
			//获取配置文件的位置
			String path = JDBCUtil.class.getClassLoader().getResource("db_properties").getPath();
			
			in = new FileInputStream(path);
			p.load(in);
			
			ds = new DruidDataSourceFactory().createDataSource(p);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				if(in != null) in.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public static DataSource getDataSource() {
		return ds;
	}
	public static Connection getConnection() {
		try {
			conn = DriverManager.getConnection("jdbc:mysql://47.98.186.144:3306/test_wj","root","666666");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return conn;
	}
}
