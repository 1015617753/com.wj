package org.wj.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.wj.dao.RoleDao;
import org.wj.entity.Priv;
import org.wj.entity.Role;
import org.wj.util.JDBCUtil;
public class RoleDaoImpl implements RoleDao {
	QueryRunner qr = new QueryRunner(JDBCUtil.getDataSource());

	@Override
	public List<Role> selRoleById(int rid) {
		List<Role> lr = null;
		String sql = "select * from tc_role where id="+rid;
		try {
			lr =  qr.query(sql, new BeanListHandler<Role>(Role.class));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lr;
	}

	@Override
	public List<Role> selAllRole() {
		List<Role> lr = null;
		String sql = "select * from tc_role";
		try {
			lr = qr.query(sql, new BeanListHandler<Role>(Role.class));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lr;
	}

	@Override
	public List<Role> selRnameByAid(int aid) {
		List<Role> lr = null;
		String sql = "select * from tc_role where id in(select rid from tc_admin_role where aid = ?)";
				   
		try {
			lr = qr.query(sql, new BeanListHandler<Role>(Role.class),aid);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lr;
	}

	@Override
	public int addRole(Role role) {
		// TODO 自动生成的方法存根
				int a =-1;
				int i = 0 ;
				Connection conn = JDBCUtil.getConnection();
				PreparedStatement ps = null;
				ResultSet rs = null;
				String sql = "insert into tc_role(rname) values(?)";
				try {
				    ps = conn.prepareStatement(sql,PreparedStatement.RETURN_GENERATED_KEYS);
					//i = qr.update(sql,role.getRname());
					ps.setString(1, role.getRname());
					ps.executeUpdate();
					rs = ps.getGeneratedKeys();
					if(rs.next()) a = rs.getInt(1);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				return a;
	}

	@Override
	public int addRolePrivs(Role role) {
		int i = 0 ;
		
		String sql = "insert into tc_role_priv(rid,pid) values(?,?)";
		try {
			List<Priv> lp = role.getLp();
			for(Priv priv : lp) {
			i = i+qr.update(sql,role.getId(),priv.getPid());
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public int deleteRoles(int rid) {
		int i = 0 ;
		
		String sql = "delete from tc_role where id = ?";
		try {
			i = qr.update(sql,rid);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public int deleteRlPriv(int rid) {
		int i = 0 ;
		
		String sql = "delete from tc_role_priv where rid = ?";
		try {
			i = qr.update(sql,rid);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public int updateRl(Role role) {
		// TODO 自动生成的方法存根
		int i = 0 ;
		
		String sql = "update tc_role set rname=? where id = ?";
		try {
			i = qr.update(sql,role.getRname(),role.getId());
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}

	public Role selRoleByRid(int rid) {
		Role role = null;
		String sql = "select * from tc_role where id=?";
		try {
			role = qr.query(sql , new BeanHandler<Role>(Role.class),rid);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return role;
	}

	@Override
	public int updateRoleByRid(Role role) {
		int i = 0;
		String sql = "update tc_role set rname=? where id=?";
		try {
			i = qr.update(sql , role.getRname(),role.getId());
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public int delRoPrByRid(int id) {
		int i = 0;
		String sql = "delete from tc_role_priv where rid=?";
		try {
			i = qr.update(sql , id);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}

	public int insertRoPr(int id, int pid) {
		int i = 0;
		String sql = "insert into tc_role_priv(rid,pid) values(?,?)";
		try {
			i = qr.update(sql , id,pid);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}
}
