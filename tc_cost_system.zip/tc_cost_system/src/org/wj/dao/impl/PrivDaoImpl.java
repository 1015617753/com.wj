package org.wj.dao.impl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import org.wj.dao.PrivDao;
import org.wj.entity.Priv;
import org.wj.util.JDBCUtil;

public class PrivDaoImpl implements PrivDao {

	QueryRunner qr = new QueryRunner(JDBCUtil.getDataSource());
	List<Priv> lp = null;
	
	@Override
	public List<Priv> selPrivByAid(int aid) {
		String sql = "select pid,pclass,purl,name from tc_priv where pid in(select pid from tc_role_priv where rid in(select rid from tc_admin_role where aid=?))";
		try {
			//将查询的结果集封装到集合对象中
			lp = qr.query(sql, new BeanListHandler<Priv>(Priv.class),aid);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return lp;
	}

	@Override
	public List<Priv> selPrivByRid(int rid) {
		String sql = "select pid,pclass,purl,name,state from tc_priv where pid in(select pid from tc_role_priv where rid=?) and state=0";
		try {
			lp = qr.query(sql, new BeanListHandler<Priv>(Priv.class),rid);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return lp;
	}

	@Override
	public List<Priv> selAllPrivs() {
		String sql = "select pid,pclass,purl,name,state from tc_priv";
		try {
			lp = qr.query(sql, new BeanListHandler<Priv>(Priv.class));
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return lp;
	}

}

