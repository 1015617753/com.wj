package org.wj.dao.impl;

import java.sql.Date;
import java.sql.SQLException;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.wj.entity.Admin;
import org.wj.util.JDBCUtil;

public class AdminDaoImpl implements AdminDao {
	
	//获取连接
	QueryRunner qr = new QueryRunner(JDBCUtil.getDataSource());

	@Override
	public Admin selAdminByNP(Admin admin) {
		Admin ad = null;
		
		String sql = "select * from tc_admin where acname=? and apwd=?";
		try {
			//将查询的结果封装成admin对象
			ad = qr.query(sql, new BeanHandler<Admin>(Admin.class),admin.getAcname(),admin.getApwd());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ad;
	}

	@Override
	public int updatePassword(Admin admin) {
		// TODO 自动生成的方法存根
		int i = 0 ;
		String sql = "update tc_admin set apwd=? where id=?";
		try {
			//将查询的结果封装成admin对象
			
			i = qr.update(sql,admin.getApwd(),admin.getId());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public int updeteAdminMsg(Admin admin) {
		int i = 0 ;
		String sql = "update tc_admin set aname=?,atel=?,aemail=?,createtime=? where id=?";
		try {
			//将查询的结果封装成admin对象
			
			i = qr.update(sql,admin.getAname(),admin.getAtel(),admin.getAemail(),new Date(new java.util.Date().getTime()),admin.getId());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}
}

